"""
Simplified Lambda handler for NHTSA Recall Analyzer
Uses only boto3 (pre-installed in Lambda) - no heavy dependencies
"""

import json
import boto3
import os
import re
from typing import Optional

# Initialize Bedrock client
bedrock_runtime = None

def get_bedrock_client():
    global bedrock_runtime
    if bedrock_runtime is None:
        bedrock_runtime = boto3.client(
            'bedrock-runtime',
            region_name=os.environ.get('AWS_REGION', 'us-east-1')
        )
    return bedrock_runtime

def parse_vehicle_info(query: str) -> dict:
    """Extract vehicle info using regex (no LLM needed for simple cases)"""

    # Common patterns
    year_pattern = r'(19|20)\d{2}'

    # Known makes
    makes = ['ford', 'chevrolet', 'chevy', 'toyota', 'honda', 'nissan', 'dodge',
             'ram', 'gmc', 'bmw', 'mercedes', 'audi', 'volkswagen', 'vw', 'hyundai',
             'kia', 'subaru', 'mazda', 'lexus', 'acura', 'infiniti', 'jeep']

    # Known models
    models = ['f-150', 'f150', 'silverado', 'camry', 'accord', 'civic', 'altima',
              'mustang', 'corvette', 'tacoma', 'rav4', 'cr-v', 'crv', 'pilot',
              'explorer', 'escape', 'edge', 'fusion', 'focus', 'ranger', 'bronco']

    query_lower = query.lower()

    # Extract year
    year_match = re.search(year_pattern, query)
    year = year_match.group(0) if year_match else None

    # Extract make
    make = None
    for m in makes:
        if m in query_lower:
            make = m.title()
            if make == 'Chevy':
                make = 'Chevrolet'
            elif make == 'Vw':
                make = 'Volkswagen'
            break

    # Extract model
    model = None
    for m in models:
        if m in query_lower:
            model = m.upper() if '-' in m or len(m) <= 4 else m.title()
            break

    return {
        'year': year,
        'make': make,
        'model': model
    }

def classify_query(query: str) -> str:
    """Classify query type based on keywords"""
    query_lower = query.lower()

    if 'recall' in query_lower:
        return 'recall'
    elif 'tsb' in query_lower or 'technical service' in query_lower:
        return 'tsb'
    elif 'complaint' in query_lower:
        return 'complaint'
    else:
        return 'general'

def get_sample_data(vehicle_info: dict, query_type: str) -> list:
    """
    Return sample NHTSA data for demonstration
    In production, this would query S3/FAISS index
    """

    make = vehicle_info.get('make', 'Ford')
    model = vehicle_info.get('model', 'F-150')
    year = vehicle_info.get('year', '2019')

    sample_recalls = [
        {
            "campaign_number": "23V456",
            "make": make,
            "model": model,
            "year": year,
            "component": "FUEL SYSTEM",
            "summary": f"Certain {year} {make} {model} vehicles may experience fuel pump failure, which can cause the engine to stall without warning.",
            "remedy": "Dealers will replace the fuel pump free of charge.",
            "report_date": "2023-08-15"
        },
        {
            "campaign_number": "22V789",
            "make": make,
            "model": model,
            "year": str(int(year) - 1) if year else "2018",
            "component": "AIR BAGS",
            "summary": f"The front passenger air bag may not deploy correctly in certain crash conditions.",
            "remedy": "Dealers will update the air bag control module software.",
            "report_date": "2022-11-20"
        }
    ]

    sample_tsbs = [
        {
            "tsb_number": "TSB-21-2345",
            "make": make,
            "model": model,
            "year": year,
            "component": "ENGINE",
            "summary": f"Some {year} {make} {model} owners may experience rough idle or engine hesitation at low speeds.",
            "remedy": "Reprogram the powertrain control module (PCM) to the latest calibration."
        }
    ]

    sample_complaints = [
        {
            "odi_number": "11234567",
            "make": make,
            "model": model,
            "year": year,
            "component": "ELECTRICAL SYSTEM",
            "summary": "Battery drains overnight even when vehicle is off. Multiple owners reporting same issue.",
            "crash": False,
            "fire": False
        }
    ]

    if query_type == 'recall':
        return sample_recalls
    elif query_type == 'tsb':
        return sample_tsbs
    elif query_type == 'complaint':
        return sample_complaints
    else:
        return sample_recalls + sample_tsbs

def generate_response_with_bedrock(query: str, vehicle_info: dict, documents: list) -> str:
    """Generate response using Claude via Bedrock"""

    client = get_bedrock_client()

    # Format documents for context
    docs_text = "\n\n".join([
        f"Document {i+1}:\n" + "\n".join([f"- {k}: {v}" for k, v in doc.items()])
        for i, doc in enumerate(documents)
    ])

    vehicle_str = f"{vehicle_info.get('year', '')} {vehicle_info.get('make', '')} {vehicle_info.get('model', '')}".strip()

    prompt = f"""Based on the following NHTSA documents, answer the user's question about {vehicle_str if vehicle_str else 'their vehicle'}.

User Question: {query}

Relevant Documents:
{docs_text}

Provide a helpful, concise response that:
1. Directly answers the question
2. Lists any relevant recall campaign numbers
3. Explains what the issue is and the remedy
4. Recommends contacting a dealer or checking NHTSA.gov for official information

Response:"""

    try:
        response = client.invoke_model(
            modelId='anthropic.claude-3-haiku-20240307-v1:0',
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1024,
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            })
        )

        result = json.loads(response['body'].read())
        return result['content'][0]['text']

    except Exception as e:
        # Fallback response if Bedrock fails
        return generate_fallback_response(vehicle_info, documents)

def generate_fallback_response(vehicle_info: dict, documents: list) -> str:
    """Generate response without LLM if Bedrock fails"""

    vehicle_str = f"{vehicle_info.get('year', '')} {vehicle_info.get('make', '')} {vehicle_info.get('model', '')}".strip()

    response = f"Here's what I found for {vehicle_str}:\n\n"

    for doc in documents:
        if 'campaign_number' in doc:
            response += f"**Recall {doc['campaign_number']}**\n"
            response += f"- Component: {doc.get('component', 'N/A')}\n"
            response += f"- Issue: {doc.get('summary', 'N/A')}\n"
            response += f"- Remedy: {doc.get('remedy', 'N/A')}\n\n"
        elif 'tsb_number' in doc:
            response += f"**TSB {doc['tsb_number']}**\n"
            response += f"- Component: {doc.get('component', 'N/A')}\n"
            response += f"- Issue: {doc.get('summary', 'N/A')}\n\n"

    response += "\n*Please verify this information at NHTSA.gov or contact your dealer.*"
    return response

def lambda_handler(event, context):
    """Main Lambda handler"""

    # Add CORS headers
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
        'Access-Control-Allow-Methods': 'POST,OPTIONS'
    }

    # Handle OPTIONS request (CORS preflight)
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }

    try:
        # Parse request body
        body = event.get('body', '{}')
        if isinstance(body, str):
            body = json.loads(body)

        query = body.get('query', '')

        if not query:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': 'Missing query parameter'})
            }

        # Step 1: Parse vehicle info
        vehicle_info = parse_vehicle_info(query)

        # Step 2: Classify query type
        query_type = classify_query(query)

        # Step 3: Get relevant documents (sample data for demo)
        documents = get_sample_data(vehicle_info, query_type)

        # Step 4: Generate response with Bedrock
        response_text = generate_response_with_bedrock(query, vehicle_info, documents)

        # Build response
        result = {
            'response': response_text,
            'vehicle_info': vehicle_info,
            'query_type': query_type,
            'sources': [
                {
                    'id': doc.get('campaign_number') or doc.get('tsb_number') or doc.get('odi_number'),
                    'type': 'recall' if 'campaign_number' in doc else 'tsb' if 'tsb_number' in doc else 'complaint'
                }
                for doc in documents
            ]
        }

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(result)
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }
